import React from 'react';
import { Heart, Code, Palette, Coffee } from 'lucide-react';

const About: React.FC = () => {
  const interests = [
    { icon: Code, title: 'Clean Code', description: 'Writing maintainable, efficient code' },
    { icon: Palette, title: 'UI/UX Design', description: 'Creating beautiful user experiences' },
    { icon: Heart, title: 'Problem Solving', description: 'Finding creative solutions' },
    { icon: Coffee, title: 'Continuous Learning', description: 'Always exploring new technologies' },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">About Me</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            I'm a passionate frontend developer with a fresh perspective and enthusiasm for creating 
            meaningful digital experiences.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="prose prose-lg text-gray-600">
              <p>
                As a recent computer science graduate, I bring a unique combination of theoretical knowledge 
                and practical skills to the world of web development. My journey began with a curiosity 
                about how things work, which led me to fall in love with coding.
              </p>
              <p>
                I specialize in modern frontend technologies including React, TypeScript, and Tailwind CSS. 
                My goal is to create web applications that are not only functional but also provide 
                exceptional user experiences.
              </p>
              <p>
                When I'm not coding, you'll find me exploring new design trends, contributing to open-source 
                projects, or learning about the latest developments in web technology.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <span className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                Team Player
              </span>
              <span className="px-4 py-2 bg-emerald-100 text-emerald-800 rounded-full text-sm font-medium">
                Quick Learner
              </span>
              <span className="px-4 py-2 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                Creative Thinker
              </span>
              <span className="px-4 py-2 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">
                Detail Oriented
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {interests.map((interest, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-gray-50 to-gray-100 p-6 rounded-xl hover:from-blue-50 hover:to-emerald-50 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-lg"
              >
                <div className="text-blue-600 mb-4">
                  <interest.icon size={32} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{interest.title}</h3>
                <p className="text-sm text-gray-600">{interest.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;